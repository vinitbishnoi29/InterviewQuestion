const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/question');

const db = mongoose.connection;

db.on('error', ()=>{ 
    console.log('error in connecting');
})
db.once('open',function(){ 
    console.log('db is connected');
})

module.exports = db;