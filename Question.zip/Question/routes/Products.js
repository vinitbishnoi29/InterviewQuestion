const express = require('express');
const productsController = require('../controllers/ProductController')

const router = express.Router();


router.get('/',productsController.products);

router.post('/create', productsController.create);

router.post('/update_quantity',productsController.updateQuantity);

module.exports = router;
