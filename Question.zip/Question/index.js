const bodyParser = require('body-parser');
const express = require('express');

const mongooseDataBase = require('./config/mongoose');
const app = express();
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended : true}));
//later
app.use('/products', require('./routes/Products'));
app.listen(2000,function(){ 
    console.log("Server is running on port number 2000");
});



