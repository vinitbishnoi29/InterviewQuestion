const Product = require('../models/product');


module.exports.products = function(req,res){ 
    Product.find({}, function (err,foundProducts){ 
        if(err){ 
            res.send(err);
        }else{ 
            res.send(foundProducts);
        }
    });
}
module.exports.create = function(req,res){ 
    const newProduct = new Product({ 
        name : req.body.name,
        quantity : req.body.quantity
    });
    newProduct.save(function(err){ 
        if(err){ 
            res.send(err);
        }else{ 
            res.send('New Product added Succesfully');
        }
    })
}

module.exports.updateQuantity =  async (req, res) => {
        const { products } = req.body;
        try {
          for (const { name, quantity } of products) {
            const product = await Product.findOne({ name });
            if (!product) {
              await Product.create({ name, quantity });
            } else {
              product.quantity += quantity;
              await product.save();
            }
          }
    res.status(200).send('Products updated successfully');
  } catch (error) {
    res.status(500).send('Internal server error');
  }
}


